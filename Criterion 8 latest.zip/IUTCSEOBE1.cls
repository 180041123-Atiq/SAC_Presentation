% Guard for non-luaLaTeX compilers
\RequirePackage{ifluatex}
\ifluatex\relax\else
% If false, give an error message and stop the compilation
\PackageError{IUTCSEOBE}{This class requires LuaLaTeX}{Kindly use LuaLaTeX to compile this document}
\stop
\fi

\NeedsTeXFormat{LaTeX2e}
\ProvidesClass{IUTCSEOBE}[2026/03/15 An experimental LaTeX book class to be used for creating OBE book within the Computer Science and Engineering (CSE) department of Islamic University of Technology (IUT).]

\DeclareOption*{\PassOptionsToClass{\CurrentOption}{report}}
\ProcessOptions\relax

\LoadClass[12pt]{report}

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% TYPE SETTING %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
\usepackage{xltabular}
\RequirePackage[a4paper,
top=0.7in, bottom=0.7in,
right=0.7in,left=0.7in,
bindingoffset=0cm, showframe=false]{geometry}

% Chapter Style
% \RequirePackage[Glenn]{fncychap}

% Header and footer
%\RequirePackage{fancyhdr}
%\fancyfoot[le, ro]{\thepage}
%\fancyhead[le]{\footnotesize \nouppercase\theEvenHead}
%\fancyhead[ro]{\footnotesize \nouppercase\theOddHead}
%\fancyfoot[c]{}
%\fancyhead[c]{}
%\fancyhead[lo, re]{}
%\renewcommand{\headrulewidth}{0pt}
%\pagestyle{fancy}

% Heading styles
\setcounter{secnumdepth}{3}

\RequirePackage{titlesec}

\titleformat{\paragraph}
{\normalfont\normalsize\bfseries}
{\theparagraph}{1em}{}

\titleformat{\subparagraph}
{\normalfont\normalsize\itshape}
{\thesubparagraph}{1em}{}

% Citation Handling
\RequirePackage[style=ieee]{biblatex}

% For Testing
\RequirePackage{kantlipsum}

% Typeface
\RequirePackage[T1]{fontenc}
\RequirePackage[bitstream-charter]{mathdesign}

% Writing Environemnt
\RequirePackage{multicol}
\RequirePackage{ragged2e}

% Graphics
\RequirePackage{graphicx}
\RequirePackage{wrapfig}

% Table Modifier
\RequirePackage{array}
\RequirePackage{tabularx}
\newcolumntype{L}{> {\RaggedRight\arraybackslash} m}
\newcolumntype{C}{> {\Centering\arraybackslash} m}
\newcolumntype{R}{> {\RaggedLeft\arraybackslash} m}
\newcolumntype{B}{> {\RaggedRight\arraybackslash} p}
\newcolumntype{M}{> {\Centering\arraybackslash} p}
\newcolumntype{D}{> {\RaggedLeft\arraybackslash} p}
\newcolumntype{Y}{> {\Centering\arraybackslash} X}
\newcolumntype{Z}{> {\RaggedLeft\arraybackslash} X}
\RequirePackage{multirow}
\RequirePackage{booktabs}
\RequirePackage{longtable}

% Maths
\RequirePackage{amsmath}
% \RequirePackage{amssymb}
\RequirePackage{xfrac} % for side fractions, \sfrac
\RequirePackage{annotate-equations} % For annotating course code breakdown
\renewcommand{\eqnannotationfont}{}

% Hyper linking
\RequirePackage[hidelinks]{hyperref}

% Enumeration
\RequirePackage{enumitem}

% For underlining
\RequirePackage[normalem]{ulem}
\RequirePackage{soul}
\setul{3pt}{1pt} % first one space between text and line, 2nd one is thickness

% Paragraph formatting
\RequirePackage{parskip}

% For PDF inclusion
\RequirePackage{pdfpages}
\includepdfset{
    scale=0.9,
    frame=true,
    pagecommand={\thispagestyle{plain}}
}

% For Appendix
\RequirePackage[toc,page]{appendix}

